// GroceryItemRepository.java
package com.questionpro.repository;

import com.questionpro.models.GroceryItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GroceryItemRepository extends JpaRepository<GroceryItem, Long> {
    List<GroceryItem> findByInventoryGreaterThan(int quantity);
    List<GroceryItem> findByIdIn(List<Long> ids);
}
