package com.questionpro.rest;

import com.questionpro.dto.GroceryItemDTO;
import com.questionpro.service.GroceryItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminRestServiceImpl {

    @Autowired
    private GroceryItemService groceryItemService;

    @PostMapping("/add")
    public GroceryItemDTO addGroceryItem(@RequestBody GroceryItemDTO item) {
        return groceryItemService.saveGroceryItem(item);
    }

    @GetMapping("/view")
    public List<GroceryItemDTO> viewGroceryItems() {
        return groceryItemService.getAllGroceryItems();
    }

    @DeleteMapping("/remove/{itemId}")
    public String removeGroceryItem(@PathVariable Long itemId) {
        groceryItemService.deleteGroceryItem(itemId);
        return "Grocery item removed successfully by Admin";
    }

    @PutMapping("/update/{itemId}")
    public GroceryItemDTO updateGroceryItem(@PathVariable Long itemId, @RequestBody GroceryItemDTO updateRequest) throws Exception {
        return groceryItemService.updateGroceryItem(itemId, updateRequest);
    }

    @PostMapping("/manageInventory/{itemId}")
    public GroceryItemDTO manageInventory(@PathVariable Long itemId, @RequestParam int quantity) throws Exception {
        return groceryItemService.manageInventory(itemId, quantity);
    }
}
