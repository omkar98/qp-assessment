package com.questionpro.rest;

import com.questionpro.dto.GroceryItemDTO;
import com.questionpro.service.GroceryItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/grocery")
public class GroceryItemRestServiceImpl {

    @Autowired
    private GroceryItemService groceryItemService;
    @GetMapping("/items")
    public List<GroceryItemDTO> viewAvailableGroceryItems() {
        return groceryItemService.viewAvailableGroceryItems();
    }

    @PostMapping("/bookOrder")
    public String bookOrder(@RequestBody List<Long> itemIds) throws Exception {
        groceryItemService.bookOrder(itemIds);
        return "Order booked successfully by User";
    }
}
