package com.questionpro.security;

import com.questionpro.enums.UserRole;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    private static final String adminUserName = "Admin";
    private static final String normalUserName = "User";
    // Configuration specific to method security
    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder encoder) {
        UserDetails admin = User.withUsername(adminUserName).password(encoder.encode(adminUserName)).roles(UserRole.ADMIN.toString()).build();
        UserDetails user = User.withUsername(normalUserName).password(encoder.encode(normalUserName)).roles(UserRole.USER.toString()).build();
        return new InMemoryUserDetailsManager(admin, user);
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()
                .authorizeHttpRequests().requestMatchers("/admin/**").hasRole(UserRole.ADMIN.toString())
                .and().httpBasic().and()
                .csrf().disable()
                .authorizeHttpRequests().requestMatchers("/grocery/**").hasRole(UserRole.USER.toString())
                .and().httpBasic()
                .and().build();
    }

    @Bean
    public PasswordEncoder  passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
