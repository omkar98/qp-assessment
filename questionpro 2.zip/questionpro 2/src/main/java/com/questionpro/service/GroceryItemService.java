// GroceryItemService.java
package com.questionpro.service;

import com.questionpro.dto.GroceryItemDTO;
import com.questionpro.models.GroceryItem;
import com.questionpro.repository.GroceryItemRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.List;
import java.util.Optional;

@Service
public class GroceryItemService {
    private static final Logger logger = LoggerFactory.getLogger(GroceryItemService.class);

    @Autowired
    private GroceryItemRepository groceryItemRepository;


    public List<GroceryItemDTO> getAllGroceryItems() {
        return groceryItemRepository.findAll().stream()
                .map(item -> {
                    GroceryItemDTO itemDTO = new GroceryItemDTO();
                    BeanUtils.copyProperties(item, itemDTO);
                    return itemDTO;
                }).toList();
    }

    public GroceryItem getGroceryItemById(Long id) {
        return groceryItemRepository.findById(id).orElse(null);
    }

    public GroceryItemDTO saveGroceryItem(GroceryItemDTO groceryItemDTO) {
        GroceryItem item = new GroceryItem();
        BeanUtils.copyProperties(groceryItemDTO, item);
        try {
            item = groceryItemRepository.save(item);
        } catch (Exception e) {
            logger.error(String.format("Cannot add Item. Error - %s.", e.getMessage()));
        }
        BeanUtils.copyProperties(item, groceryItemDTO);
        return groceryItemDTO;
    }

    public void deleteGroceryItem(Long id) {
        try {
            groceryItemRepository.deleteById(id);
        } catch (Exception e) {
            logger.error(String.format("Cannot delete Item. Error - %s .", e.getMessage()));
        }
    }

    public GroceryItemDTO updateGroceryItem(Long id, GroceryItemDTO updateRequest) throws Exception {
        if(id.equals(updateRequest.getId())) {
            validateUpdateItem(updateRequest, id);
        } else {
            logger.error("Invalid Request made. Please verify the data correctly.");
            throw new Exception("Invalid Request made. Please verify the data correctly.");
        }
        return updateRequest;
    }

    private GroceryItemDTO validateUpdateItem(GroceryItemDTO updateRequest, Long id) throws Exception {
        Optional<GroceryItem> optionalItem = groceryItemRepository.findById(id);
        if (optionalItem.isPresent()) {
            GroceryItem existingItem = optionalItem.get();
            if (!ObjectUtils.isEmpty(updateRequest.getName())) {
                existingItem.setName(updateRequest.getName());
            }
            if (!ObjectUtils.isEmpty(updateRequest.getPrice())) {
                existingItem.setPrice(updateRequest.getPrice());
            }
            if (!ObjectUtils.isEmpty(updateRequest.getInventory())) {
                existingItem.setInventory(updateRequest.getInventory());
            }
            GroceryItem updatedItem = groceryItemRepository.save(existingItem);
            updateRequest.setId(updatedItem.getId());
            return updateRequest;
        } else {
            logger.error("Invalid Request made. Item not found.");
            throw new Exception("Invalid Request made. Item not found.");
        }
    }

    public GroceryItemDTO manageInventory(Long itemId, int quantity) throws Exception {
        Optional<GroceryItem> optionalItem = groceryItemRepository.findById(itemId);
        GroceryItemDTO updateRequest = new GroceryItemDTO();
        BeanUtils.copyProperties(optionalItem.get(), updateRequest);
        updateRequest.setInventory(quantity);
        updateRequest = validateUpdateItem(updateRequest, itemId);
        return updateRequest;
    }

    public List<GroceryItemDTO> viewAvailableGroceryItems() {
        return groceryItemRepository.findByInventoryGreaterThan(0).stream()
                .map(item -> {
                    GroceryItemDTO itemDTO = new GroceryItemDTO();
                    BeanUtils.copyProperties(item, itemDTO);
                    return itemDTO;
                }).toList();

    }

    public void bookOrder(List<Long> itemIds) throws Exception {
        List<GroceryItem> itemsToBook = groceryItemRepository.findByIdIn(itemIds);
        for (GroceryItem item : itemsToBook) {
            if (item.getInventory() > 0) {
                item.setInventory(item.getInventory() - 1);
            } else {
                logger.error("Error: Item " + item.getId() + " is out of stock");
                throw new Exception("Item Out of Stock");
            }
        }
        groceryItemRepository.saveAll(itemsToBook);

    }

}
