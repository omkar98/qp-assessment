package com.questionpro.enums;

// Role enum
public enum UserRole {
    ADMIN, USER
}
